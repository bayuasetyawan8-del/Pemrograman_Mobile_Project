// Interface untuk satu data buku yang dikirim oleh Open Library API.
export interface Buku {
  key: string;
  title: string;
  author_name?: string[];
  first_publish_year?: number;
  edition_count?: number;
}

// Interface untuk bentuk response pencarian dari Open Library API.
// docs berisi daftar objek Buku, sedangkan numFound berisi jumlah hasil yang ditemukan API.
export interface ResponsPencarianBuku {
  docs: Buku[];
  numFound?: number;
}

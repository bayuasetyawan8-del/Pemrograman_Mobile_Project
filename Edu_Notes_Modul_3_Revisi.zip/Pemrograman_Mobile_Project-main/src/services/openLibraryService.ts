import type { Buku, ResponsPencarianBuku } from "../types/book";

const BASE_URL = "https://openlibrary.org/search.json";

// Memeriksa satu data buku sebelum data dari server digunakan di aplikasi.
function adalahBuku(data: unknown): data is Buku {
  if (typeof data !== "object" || data === null) {
    return false;
  }

  const buku = data as Record<string, unknown>;

  return (
    typeof buku.key === "string" &&
    typeof buku.title === "string" &&
    (buku.author_name === undefined ||
      (Array.isArray(buku.author_name) &&
        buku.author_name.every((nama) => typeof nama === "string"))) &&
    (buku.first_publish_year === undefined ||
      typeof buku.first_publish_year === "number") &&
    (buku.edition_count === undefined ||
      typeof buku.edition_count === "number")
  );
}

// Memeriksa apakah bentuk response dari API sesuai dengan interface yang dibuat.
function adalahResponsPencarianBuku(
  data: unknown
): data is ResponsPencarianBuku {
  if (typeof data !== "object" || data === null) {
    return false;
  }

  const response = data as Record<string, unknown>;

  return (
    Array.isArray(response.docs) &&
    response.docs.every(adalahBuku) &&
    (response.numFound === undefined ||
      typeof response.numFound === "number")
  );
}

// CUSTOM ASYNC FUNCTION:
// Fungsi ini dibuat sendiri dan mengembalikan Promise berisi response pencarian buku.
export function ambilDataBuku(
  kataKunci: string
): Promise<ResponsPencarianBuku> {
  return new Promise<ResponsPencarianBuku>((resolve, reject) => {
    const kataKunciBersih = kataKunci.trim();

    if (!kataKunciBersih) {
      reject(new Error("Kata kunci pencarian tidak boleh kosong."));
      return;
    }

    const fields =
      "key,title,author_name,first_publish_year,edition_count";
    const url =
      `${BASE_URL}?q=${encodeURIComponent(kataKunciBersih)}` +
      `&fields=${encodeURIComponent(fields)}&limit=10`;

    // PRE-BUILT ASYNC FUNCTION:
    // fetch() adalah fungsi bawaan JavaScript untuk mengirim HTTP request.
    // fetch() mengembalikan Promise yang berisi objek Response.
    fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
    })
      .then((response) => {
        // Jika status HTTP bukan 2xx, lempar error agar ditangani oleh .catch().
        if (!response.ok) {
          throw new Error(
            `Permintaan API gagal. Status HTTP: ${response.status}.`
          );
        }

        // response.json() juga mengembalikan Promise.
        return response.json();
      })
      .then((data: unknown) => {
        // Validasi bentuk data sebelum dimasukkan ke object bertipe interface.
        if (!adalahResponsPencarianBuku(data)) {
          throw new Error("Format data dari API tidak sesuai.");
        }

        const hasilPencarian: ResponsPencarianBuku = data;

        // resolve() menandakan proses berhasil dan mengirimkan hasilnya.
        resolve(hasilPencarian);
      })
      .catch((error: unknown) => {
        // reject() menandakan proses gagal, misalnya tidak ada koneksi internet
        // atau server tidak dapat dihubungi.
        const pesanError =
          error instanceof Error
            ? error
            : new Error("Terjadi kesalahan saat menghubungi Open Library API.");

        reject(pesanError);
      });
  });
}

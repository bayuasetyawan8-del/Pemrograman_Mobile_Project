# Edu Notes – Aplikasi Catatan Kuliah

Edu Notes adalah aplikasi mobile berbasis **React Native**, **Expo**, dan **TypeScript** untuk membantu mahasiswa mencatat materi perkuliahan serta mencari referensi buku.

## Fitur utama

- Menambahkan catatan kuliah.
- Melihat daftar dan detail catatan.
- Menghapus catatan.
- Melihat panduan penggunaan aplikasi.
- Mencari referensi buku menggunakan **Open Library API**.

> Catatan: data catatan pada versi ini masih disimpan sementara di state aplikasi. Fitur pencarian buku mengambil data langsung dari API eksternal dan membutuhkan koneksi internet.

## Menjalankan proyek

1. Instal Node.js versi LTS.
2. Buka folder proyek ini di Visual Studio Code.
3. Buka terminal VS Code pada folder yang berisi `package.json`.
4. Instal dependensi:

   ```bash
   npm install
   ```

5. Jalankan Expo:

   ```bash
   npx expo start
   ```

6. Tekan `w` untuk membuka aplikasi di browser, atau pindai QR code melalui Expo Go di perangkat Android.

## Penerapan Modul 3 – Asynchronous & API Call

Penerapan materi Modul 3 terdapat pada file berikut:

- `src/types/book.ts`: interface untuk data buku dan response API.
- `src/services/openLibraryService.ts`: External API, HTTP GET, `fetch`, `.then()`, `resolve()`, dan `reject()`.
- `src/app/index.tsx`: custom async function `cariBuku()`, `async/await`, status loading, dan penanganan error.

Lihat [PANDUAN_MODUL_3.md](./PANDUAN_MODUL_3.md) untuk langkah pengujian dan penjelasan alur kode.

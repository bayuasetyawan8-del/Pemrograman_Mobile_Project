# Panduan Penerapan Modul 3 pada Edu Notes

Dokumen ini menjelaskan bagian proyek Edu Notes yang menerapkan materi Modul 3 Pemrograman Mobile: Pemrograman Asynchronous & API Call.

## 1. Persiapan di Visual Studio Code

1. Ekstrak ZIP proyek ke folder yang mudah ditemukan.
2. Buka Visual Studio Code.
3. Pilih **File > Open Folder**, lalu pilih folder `Pemrograman_Mobile_Project-main`.
4. Buka terminal VS Code melalui **Terminal > New Terminal**.
5. Pastikan terminal berada di folder proyek (folder yang berisi `package.json`).
6. Jalankan `npm install` dan tunggu sampai proses instalasi selesai.

## 2. Menjalankan aplikasi

Jalankan perintah berikut di terminal:

```bash
npx expo start
```

- Untuk menjalankan melalui browser, tekan `w` pada terminal Expo.
- Untuk Android, buka aplikasi Expo Go di ponsel lalu pindai QR code yang tampil pada terminal.
- Komputer dan ponsel sebaiknya terhubung ke jaringan yang sama. Koneksi internet diperlukan untuk mengambil data dari Open Library API.

## 3. Cara menguji fitur API

1. Buka halaman utama Edu Notes.
2. Gulir ke bagian **Cari Buku dari Open Library**.
3. Masukkan kata kunci, misalnya `Java Programming`.
4. Tekan **Cari Buku**.
5. Aplikasi menampilkan status pemuatan, kemudian daftar buku dari Open Library.
6. Periksa judul, penulis, tahun terbit, jumlah edisi, serta jumlah hasil yang dikembalikan API.

Jika tidak ada hasil, aplikasi menampilkan pesan bahwa buku tidak ditemukan. Jika koneksi atau server bermasalah, aplikasi menampilkan pesan kesalahan.

## 4. Peta materi Modul 3 di dalam kode

| Materi / kriteria | Lokasi kode | Penerapan |
|---|---|---|
| External API dan HTTP GET | `src/services/openLibraryService.ts` | `fetch(url, { method: "GET" })` mengambil data dari Open Library. |
| Interface data | `src/types/book.ts` | `Buku` dan `ResponsPencarianBuku` mendefinisikan bentuk objek data. |
| Custom async function | `src/app/index.tsx` | `cariBuku()` menggunakan kata kunci `async` dan mengembalikan `Promise<void>`. |
| Custom Promise | `src/services/openLibraryService.ts` | `ambilDataBuku()` membuat Promise dengan `new Promise<ResponsPencarianBuku>()`. |
| Pre-built async function | `src/services/openLibraryService.ts` | `fetch()` dan `response.json()` merupakan fungsi bawaan berbasis Promise. |
| `.then()` | `src/services/openLibraryService.ts` | Memproses response HTTP dan data JSON secara berurutan. |
| `resolve()` | `src/services/openLibraryService.ts` | Mengirim hasil pencarian yang sudah divalidasi ketika berhasil. |
| `reject()` | `src/services/openLibraryService.ts` | Mengirim error ketika request gagal. |
| `async/await` | `src/app/index.tsx` | `await ambilDataBuku(...)` menunggu hasil pencarian. |
| Penanganan error | `src/app/index.tsx` | `try/catch/finally` mengatur pesan error dan status loading. |

## 5. Penjelasan alur proses pencarian

1. Pengguna menekan tombol **Cari Buku**.
2. Fungsi `cariBuku()` dijalankan. Fungsi ini merupakan custom async function.
3. `cariBuku()` memanggil `ambilDataBuku()` dan menunggu hasilnya menggunakan `await`.
4. `ambilDataBuku()` membuat sebuah Promise.
5. `fetch()` mengirim HTTP GET request ke Open Library API.
6. `.then()` pertama memeriksa status response dan membaca JSON.
7. `.then()` berikutnya memvalidasi data menggunakan interface dan fungsi pemeriksaan.
8. Jika berhasil, `resolve()` mengirim objek `ResponsPencarianBuku` ke pemanggil.
9. `await` menerima hasil tersebut, lalu `setDaftarBuku()` menyimpan daftar buku ke state agar ditampilkan.
10. Jika terjadi kegagalan, `.catch()` pada layanan memanggil `reject()`, lalu `catch` pada `cariBuku()` menampilkan pesan kesalahan.
11. `finally` mengubah status loading menjadi selesai.

## 6. Cara memahami resolve dan reject saat demo

- Jalur berhasil (`resolve`): lakukan pencarian dengan koneksi internet aktif. Data buku berhasil diterima dan ditampilkan.
- Jalur gagal (`reject`): jika perlu menguji penanganan error, nonaktifkan koneksi internet sementara lalu lakukan pencarian. Aplikasi seharusnya menampilkan pesan kesalahan. Aktifkan kembali koneksi setelah pengujian.

## 7. Catatan penting

- Pencarian buku membutuhkan koneksi internet karena datanya berasal dari layanan Open Library.
- Data catatan kuliah pada versi ini masih disimpan di `useState`, bukan database atau penyimpanan permanen. Hal ini terpisah dari penerapan API pencarian buku pada Modul 3.
- Sebelum demo, biasakan menjelaskan fungsi setiap bagian kode dan mencoba perubahan kecil sendiri. Saat demo, ikuti aturan asisten praktikum mengenai penggunaan modul dan AI.
